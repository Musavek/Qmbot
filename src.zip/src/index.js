// import ReactDOM from 'react-dom';
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function App() {
//   const [titles, setTitles] = useState([]);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     async function fetchPostTitles() {
//       try {
//         const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
//         const titles = response.data.map(post => post.title);
//         setTitles(titles);
//       } catch (error) {
//         setError(error.message);
//       }
//     }

//     fetchPostTitles();

//   }, []);

//   return (
//     <div>
//       <h1>Post Titles</h1>
//       {error && <p>Error: {error}</p>}
//       <ul>
//         {titles.map((title, index) => (
//           <li key={index}>{title}</li>
//         ))}
//       </ul>
//     </div>
//   );
// }
// const root = ReactDOM.createRoot(document.getElementById("root"));
// root.render(<App />);
//////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import ReactDOM from "react-dom";

// function App() {
//   const [data, setData] = useState([]);

//   useEffect(() => {
//     fetchData();
//   }, []);

//   const fetchData = async () => {
//     try {
//       const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
//       setData(response.data);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   return (
//     <div>
//       {data.map((item) => (
//         <div key={item.id} style={styles.postContainer}>
//           <h1 style={styles.title}>{item.title}</h1>
//           <p style={styles.body}>{item.body}</p>
//           <p style={styles.price}>price: {item.price}</p>
//           <p style={styles.email}>email: {item.email}</p>
//         </div>
//       ))}
//     </div>
//   );
// }

// const styles = {
//   postContainer: {
//     marginBottom: '20px',
//     padding: '10px',
//     border: '1px solid #ccc',
//     borderRadius: '5px',
//   },
//   title: {
//     fontSize: '20px',
//     fontWeight: 'bold',
//   },
//   body: {
//     fontSize: '15px',
//   },
//   price: {
//     fontSize: '15px',
//     color: 'blue',
//   },
// };

// const root = ReactDOM.createRoot(document.getElementById("root"));
// root.render(<App />);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// import ReactDOM from 'react-dom';
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function App() {
//   const [titles, setTitles] = useState([]);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     async function fetchPostTitles() {
//       try {
//         const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
//         const titles = response.data.map(post => post.title);
//         setTitles(titles);
//       } catch (error) {
//         setError(error.message);
//       }
//     }

//     fetchPostTitles();

//   }, []);  

//   return (
//     <div>
//       <h1>Post Titles</h1>
//       {error && <p>Error: {error}</p>}
//       <ul>
//         {titles.map((title, index) => (
//           <li key={index}>{title}</li>
//         ))}
//       </ul>
//     </div>
//   );
// }
// const root = ReactDOM.createRoot(document.getElementById("root"));
// root.render(<App />);
/////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////

import React, { useEffect, useState } from "react";
import axios from "axios";
import ReactDOM from "react-dom";

function App() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('https://jsonplaceholder.typicode.com/comments');
      setData(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      {data.map((item) => (
        <div key={item.id} style={styles.postContainer}>
          <h1 style={styles.title}>{item.title}</h1>
          <p style={styles.body}>{item.body}</p>
          <p style={styles.email}>Email: {item.email}</p>
          <p style={styles.name}>Name: {item.name}</p>
          <p style={styles.id}>ID: {item.id}</p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  postContainer: {
    marginBottom: '20px',
    padding: '10px',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  title: {
    fontSize: '20px',
    fontWeight: 'bold',
    marginBottom: '5px',
  },
  body: {
    fontSize: '15px',
    marginBottom: '10px',
  },
  email: {
    fontSize: '15px',
    color: 'blue',
    marginBottom: '5px',
  },
  name: {
    fontSize: '15px',
    fontWeight: 'bold',
    marginBottom: '5px',
  },
  id: {
    fontSize: '15px',
    color: 'gray',
  },
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////
